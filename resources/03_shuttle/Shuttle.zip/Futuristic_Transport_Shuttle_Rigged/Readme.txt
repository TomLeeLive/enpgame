Here is a rigged futuristic transport shuttle I made some time ago.

Animated Yes
Rigged Yes
Lowpoly (game-ready) Yes
Geometry Subdivision ready
Polygons 16,343
Vertices 18,360
Textures Yes
Materials Yes
UV Mapping Yes
Unwrapped UVs Non-overlapping

Feel free to use it for your projects.

Demo-Video: https://www.youtube.com/watch?v=FDI68lEZ4ZU
Animated 3d-preview on Sketchfab: https://sketchfab.com/models/2292ce758e114a5f87626d81404d5f44

Homepage: http://3dartdh.wordpress.com/
Contact me: https://3dartdh.wordpress.com/contact/
Sketchfab: https://sketchfab.com/dennish2010
YouTube: https://www.youtube.com/user/DennisH2010

